import esphome.codegen as cg

st7796s_ns = cg.esphome_ns.namespace("st7796s")
