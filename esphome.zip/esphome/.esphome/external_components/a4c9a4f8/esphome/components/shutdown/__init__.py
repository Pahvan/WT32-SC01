CODEOWNERS = ["@esphome/core", "@jsuanet"]
