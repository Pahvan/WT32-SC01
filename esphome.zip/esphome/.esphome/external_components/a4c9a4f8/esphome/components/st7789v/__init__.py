import esphome.codegen as cg

st7789v_ns = cg.esphome_ns.namespace("st7789v")
