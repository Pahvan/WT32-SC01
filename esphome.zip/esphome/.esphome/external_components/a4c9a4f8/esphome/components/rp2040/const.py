import esphome.codegen as cg

KEY_BOARD = "board"
KEY_RP2040 = "rp2040"

rp2040_ns = cg.esphome_ns.namespace("rp2040")
